<?php
/*
Plugin Name: SaveClips - Instagram Downloader
Description: A dedicated shortcode for downloading Instagram photos and videos.
Version: 1.0
Author: You
*/

if (!defined("ABSPATH")) exit;

/**
 * Enqueue the plugin's dedicated scripts and styles.
 */
function sc_insta_enqueue_assets() {
    wp_enqueue_style(
        'sc-insta-style',
        plugin_dir_url(__FILE__) . 'style-instagram.css',
        array(),
        '1.0'
    );
    wp_enqueue_script(
        'sc-insta-script',
        plugin_dir_url(__FILE__) . 'script-instagram.js',
        array(),
        '1.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'sc_insta_enqueue_assets');

/**
 * Shortcode output function.
 */
function sc_insta_form() {
    return '
    <div class="downloader-section">
        <div class="sc-video-downloader">
            <h1>Instagram Downloader</h1>
            <p class="subtitle">Download Instagram videos, Reels, photos, and carousels for free.</p>
            <div class="input-group">
                <input type="text" id="sc-insta-url-input" placeholder="Paste Instagram link here...">
                <button id="sc-insta-download-btn" onclick="downloadInstagram(document.getElementById(\'sc-insta-url-input\').value)">Download</button>
            </div>
        </div>
    </div>
    <div id="sc-insta-results-wrapper">
        <div id="sc-insta-results"></div>
    </div>
    ';
}
add_shortcode("instagram_downloader", "sc_insta_form");