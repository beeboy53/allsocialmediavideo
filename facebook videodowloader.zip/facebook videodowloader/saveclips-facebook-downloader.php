<?php
/**
 * Plugin Name:      SaveClips - Facebook Downloader
 * Description:      A simple downloader for Facebook videos. Use the shortcode [saveclips_facebook_downloader].
 * Version:          1.0.0
 * Author:           MK Tech
 * Author URI:       https://mk-tech.in
 * License:          GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Enqueue scripts and styles only when the shortcode is present.
 * This improves site performance by not loading assets on every page.
 */
function scd_fb_enqueue_assets() {
    global $post;
    
    // Check if the post object exists and if the shortcode is in the post content
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'saveclips_facebook_downloader')) {
        wp_enqueue_style(
            'scd-fb-styles',
            plugin_dir_url(__FILE__) . 'assets/style.css',
            array(),
            '1.0.0'
        );
        wp_enqueue_script(
            'scd-fb-script',
            plugin_dir_url(__FILE__) . 'assets/script.js',
            array(),
            '1.0.0',
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'scd_fb_enqueue_assets');

/**
 * Shortcode function to display the downloader.
 */
function scd_fb_display_downloader() {
    ob_start();
    ?>
    <div class="sc-facebook-downloader">
        <h1>Facebook Video Downloader</h1>
        <p class="subtitle">Download public videos from Facebook in HD for free.</p>
        
        <form id="sc-download-form">
            <div class="input-group">
                <input type="url" id="sc-url-input" placeholder="Paste Facebook video link here..." required>
                <button type="submit" id="sc-download-btn">Download</button>
            </div>
        </form>

        <div id="sc-results">
            </div>
    </div>
    <?php
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('saveclips_facebook_downloader', 'scd_fb_display_downloader');