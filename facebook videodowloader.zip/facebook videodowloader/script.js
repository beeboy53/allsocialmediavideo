document.addEventListener('DOMContentLoaded', () => {
    const downloadForm = document.getElementById('sc-download-form');
    if (!downloadForm) {
        return; // Exit if the form isn't on the page
    }

    const urlInput = document.getElementById('sc-url-input');
    const resultsDiv = document.getElementById('sc-results');
    
    // This API URL should point to your backend service
    const API_BASE_URL = 'https://saveclips-api.onrender.com';

    downloadForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const videoUrl = urlInput.value.trim();

        if (!videoUrl) {
            alert('Please paste a Facebook video URL.');
            return;
        }

        showLoader();

        try {
            const { endpoint, payload } = getApiDetails(videoUrl);
            const response = await fetch(`${API_BASE_URL}${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.detail || 'An unknown error occurred.');
            }

            displayResults(data);
        } catch (error) {
            displayError(error.message);
        }
    });
    
    // This function handles the actual download when the button is clicked
    async function forceDownload(url, title) {
        const downloadButton = document.querySelector('.download-btn-small');
        if (!downloadButton) return;
        
        const originalText = downloadButton.textContent;
        downloadButton.textContent = 'Downloading...';
        downloadButton.disabled = true;

        try {
            const response = await fetch(url);
            const blob = await response.blob();
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            const fileName = (title || 'facebook-video').replace(/[^a-z0-9_.-]/gi, '_') + '.mp4';
            link.download = fileName;
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);

        } catch (error) {
            console.error('Download failed:', error);
            alert('Could not download the file.');
        } finally {
            downloadButton.textContent = originalText;
            downloadButton.disabled = false;
        }
    }
    
    // Validates the URL and determines the API endpoint to use
    function getApiDetails(url) {
        if (url.includes('facebook.com') || url.includes('fb.watch')) {
            return {
                endpoint: '/facebook/download',
                payload: { url }
            };
        } else {
            throw new Error('Invalid URL. This downloader only supports Facebook videos.');
        }
    }

    function showLoader() {
        resultsDiv.innerHTML = `
            <div class="sc-loader">
                <div class="spinner"></div>
                <p>Fetching video, please wait...</p>
            </div>`;
    }

    function displayError(message) {
        const sanitizedMessage = message.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        resultsDiv.innerHTML = `<p style="color: #d93025; font-weight: bold;">${sanitizedMessage}</p>`;
    }

    function displayResults(data) {
        if (!data.title || !data.download_url) {
            displayError('Could not get video info. The link may be invalid or the video might be private.');
            return;
        }

        resultsDiv.innerHTML = `
            <div class="video-card">
                ${data.thumbnail ? `<img src="${data.thumbnail}" alt="Video Thumbnail">` : ''}
                <h2>${data.title}</h2>
                <div class="download-links">
                    <button class="download-btn-small">Download Video</button>
                </div>
            </div>`;

        // Add a click listener to the new download button
        const finalDownloadBtn = resultsDiv.querySelector('.download-btn-small');
        if (finalDownloadBtn) {
            finalDownloadBtn.addEventListener('click', () => {
                forceDownload(data.download_url, data.title);
            });
        }
    }
});